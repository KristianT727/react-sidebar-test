export const FooterLinks = [
    { title: "Beranda", link: "/home" },
    { title: "Artikel", link: "/articles" },
    { title: "Events", link: "/events" },
    { title: "Galeri", link: "/gallery" },
    { title: "Klien Kami", link: "/clients" },
    { title: "Login", link: "/login" },
];

export const FooterLinks2 = [
    { title: "Profile", link: "/profile" },
    { title: "Visi dan Misi", link: "/visi-misi" },
    { title: "Produk Kami", link: "/product" },
    { title: "Kontak Kami", link: "/contact" },
    { title: "About Us", link: "/about-us" },
];
