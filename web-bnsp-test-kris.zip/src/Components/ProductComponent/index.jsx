export { ProductComponent } from "./ProductComponent";
