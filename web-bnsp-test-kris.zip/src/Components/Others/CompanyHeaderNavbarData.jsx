export const CompanyHeaderNavbarData = [
    { title: "Profile", link: "/profile" },
    { title: "Visi dan Misi", link: "/visi-misi" },
    { title: "Produk Kami", link: "/product" },
    { title: "Kontak Kami", link: "/contact" },
    { title: "About Us", link: "/about-us" },
];
