export { default } from "./GalleryComponent";
