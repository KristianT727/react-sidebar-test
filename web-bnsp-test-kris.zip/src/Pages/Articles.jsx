export const Articles = () => {
    return <>Articles</>;
};
