export const Events = () => {
    return <>Events</>;
};
